#include <iostream>
#include <math.h>
#include <fstream>

using namespace std;

const int n = 5;

// Ланка зв'язаного списку:
struct Link
{
    double data;
    Link *next;
};

double **funcLab5Task1(double **arr, int m, int n)
{
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (arr[i][j] > 0)
            {
                arr[i][j] = log10(arr[i][j]);
            }
        }
    }
    return arr;
}

void funcLab5Task2(const char *filename, double **arr1, double *arr2, int m, int n)
{
    for (int i = 0; i < n; i++)
    {
        bool eq = false;
        arr2[i] = 0;

        for (int j = 0; j < m; j++)
        {
            if (arr1[j][i] < 0)
            {

                eq = true;

                arr2[i] += arr1[j][i];
            }
        }

        ofstream out(filename);

        if (eq == false)
        {
            out << "ERROR: no negative elements in the column ";
            out << i + 1;
            out << ". The corresponding element in the second array will be 0." << endl;
        }
    }
}

double **readFromFile(const char *fileName, int &count, int n, int &m)
{
    Link *first = 0;
    Link *last = 0;
    Link *link;

    ifstream in(fileName);

    int i;
    count = 0;

    while (in >> i)
    {
        count++;

        link = new Link;
        link->data = i;
        link->next = 0;

        if (last == 0)
        {
            first = link;
        }
        else
        {
            last->next = link;
        }

        last = link;
    }

    m = count / n;

    double **arr = new double *[m];
    link = first;

    for (int i = 0; i < count; i++)
    {
        arr[i] = new double[n];

        for (int j = 0; j < n; j++)
        {
            if (link)
            {
                arr[i][j] = link->data;
                link = link->next;
            }
        }
    }

    while (first)
    {
        link = first;
        first = first->next;
        delete link;
    }

    return arr;
}

// Записує елементи масиву arr довжини count
// у вказаний текстовий файл

void outToFile(const char *filename, double **arr, double **arr1, double *arr2, int n, int m, int count)
{
    ofstream out(filename);

    out << "Array:"
        << "\n";
    for (int i = count - 1; i >= 0; i--)
    {
        out << arr[i] << " ";
    }

    out << "Array 1:"
        << "\n";
    for (int i = 0; i < m; i++)
    {

        for (int j = 0; j < n; j++)

        {

            out << arr1[i][j] << "\n";
        }

        cout << "\n";
    }

    out << "Array 2:"
        << "\n";

    for (int i = 0; i < n; i++)
    {
        out << arr2[i] << "\n";
    }
}

int main()
{
    int count = 0;

    int m = 0;

    // Первоначальный массив
    double **arr = readFromFile("data.txt", count, n, m);

    // TASK1
    double **arr1 = new double *[m];
    for (int i = 0; i < m; i++)
    {
        arr1[i] = new double[n];
    }
    arr1 = funcLab5Task1(arr, n, m);

    // TASK2
    double *arr2 = new double[n];
    funcLab5Task2("results.txt", arr1, arr2, m, n);

    // outToFile("results.txt", arr, count);

    // Освобождение памяти
    for (int i = 0; i < m; i++)
    {
        delete[] arr[i];
    }
    delete[] arr;

    for (int i = 0; i < m; i++)
    {
        delete[] arr1[i];
    }
    delete[] arr1;
    delete[] arr2;

    return 0;
}